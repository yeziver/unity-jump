import pygame
import sys
import math

screen = pygame.display.set_mode((4002, 2251))
ready_text = pygame.image.load("ready.jpg")



class Sprite():
    def __init__(self, x, y, width, height,colour):
        self.x = x
        self.y = y
        self.dx = 0
        self.dy = 0
        self.width = width
        self.height = height
        self.color = colour
        self.friction = 0.9
        
    def goto(self, x, y):
        self.x = x
        self.y = y

    def render(self):
        pygame.draw.rect(screen, self.color, pygame.Rect(int(self.x-self.width/2.0), int(self.y-self.height/2.0), self.width, self.height)) 

    def is_aabb_collision(self, other):
        x_collision = (math.fabs(self.x - other.x) * 2) < (self.width + other.width)
        y_collision = (math.fabs(self.y - other.y) * 2) < (self.height + other.height)
        return (x_collision and y_collision)

    def checkCollision(self, sprite1, sprite2):
      col = pygame.sprite.collide_rect(sprite1, sprite2)
      if col == True:
          print('test')
