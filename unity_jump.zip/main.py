#im running the latest version of this on vscode so my latest changes wont show up here




import pygame
import sys
import math
import random
from Background import Background
from Sprite import Sprite

pygame.init()
pygame.display.set_caption("__UNITY")
clock = pygame.time.Clock()


WIDTH = 4002
HEIGHT = 2251
GRAVITY = 1
screen_width = WIDTH
screen_height = HEIGHT

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
ORANGE = (255,150,0)
LIGHTBLUE = (0,191,255)


font = pygame.font.SysFont("comicsansms",30)
ready_text = pygame.image.load("ready.jpg")

screen = pygame.display.set_mode((WIDTH, HEIGHT))

moving_right = False
moving_left = False

player_location = [50,50]
player_y_momentum = 0


class Player(Sprite):
    def __init__(self, x, y, width, height,colour):
        Sprite.__init__(self, x, y, width, height,colour)
        self.color=colour

    # def __init__(self,x,y,picture_path,width,height):
    #   super().__init__(x,y)
    #   self.image = pygame.image.load(picture_path)
    #   self.rect = self.image.get_rect()
    
    def move(self):
        self.x += self.dx
        self.y += self.dy
        self.dy += GRAVITY
        
    def jump(self):
        self.dy -= 15
        
    def left(self):
        self.dx -= 6
        if self.dx < -12:
          self.dx = -12
        
    def right(self):
        self.dx = 6
        if self.dx > 12:
            self.dx = 12



          




# player = Player(600, 0, 20, 40,RED,'nin.png')
# player2 = Player(600, 40, 20, 40,GREEN,'nin.png')

player = Player(300, 0, 20, 20,LIGHTBLUE)
player2 = Player(700, 40, 20, 20,(255,99,71))


allblocks = []
blocks = []
endblocks = []
endblocks.append(Sprite(300, 200, 100, 20, GREEN))
#blocks.append(Sprite(600, 200, 400, 20))
# blocks.append(Sprite)
blocks.append(Sprite(600, 400, 600, 20,ORANGE))
blocks.append(Sprite(600, 600, 1000, 20,ORANGE))
blocks.append(Sprite(1000, 500, 100, 100,ORANGE))
blocks.append(Sprite(200, 500, 40, 100,ORANGE))
blocks.append(Sprite(700, 500, 100, 30,ORANGE))
blocks.append(Sprite(400, 500, 40, 40,ORANGE))
blocks.append(Sprite(500, 500, 40, 40,ORANGE))

# platform = []
# platform.append(Sprite(600,200,400,20,  GREEN))

# level1blocks = []
# #blocks.append(Sprite(600, 200, 400, 20))
# level1blocks.append(Sprite(600, 400, 600, 20,ORANGE))
# level1blocks.append(Sprite(600, 600, 1000, 20,ORANGE))
# level1blocks.append(Sprite(1000, 500, 100, 200,ORANGE))
# level1blocks.append(Sprite(200, 500, 100, 200,ORANGE))

# allblocks.append(level1blocks)




class GameState():
    
    def __init__(self):
      self.state = 'intro'
      
      

    def intro(self):
      
      for event in pygame.event.get():
        if event.type == pygame.QUIT: 
            sys.exit()
        if event.type == pygame.MOUSEBUTTONDOWN:
          if 385 <= mouse[0] <= 513 and 315 <= mouse[1] <= 392:
            self.state = 'main_game'
      BackGround = Background('unityy.jpg', [0,0])
      screen.fill([255, 255, 255])
      screen.blit(BackGround.image, BackGround.rect)
      screen.blit(ready_text,[385,315])      

      pygame.display.flip()
      
    def main_game(self):

      BackGround = Background('download.jpeg', [0,0])
      screen.fill([255, 255, 255])
      screen.blit(BackGround.image, BackGround.rect)

      
      for event in pygame.event.get():
        if event.type == pygame.QUIT: 
            sys.exit()
      
    
  
  
  #controls
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                player.left()
            elif event.key == pygame.K_RIGHT:
                player.right()
            if event.key == pygame.K_UP:
                for block in blocks:
                    if player.is_aabb_collision(block):
                        player.jump()
                        break
  
  
          
      
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_a:
                player2.left()
            elif event.key == pygame.K_d:
                player2.right()
            elif event.key == pygame.K_w:
                for block in blocks:
                    if player2.is_aabb_collision(block):
                        player2.jump()
                        break
  
      player.move()
      player2.move()
      
    
      for block in blocks:
          if player.is_aabb_collision(block):
          
              if player.x < block.x - block.width/2.0 and player.dx > 0:
                  player.dx = 0
                  player.x = block.x - block.width/2.0 - player.width/2.0
          
              elif player.x > block.x + block.width/2.0 and player.dx < 0:
                  player.dx = 0
                  player.x = block.x + block.width/2.0 + player.width/2.0
          
              elif player.y < block.y:
                  player.dy = 0
                  player.y = block.y - block.height/2.0 - player.height/2.0 + 1
                  player.dx *= block.friction
            
              elif player.y > block.y:
                  player.dy = 0
                  player.y = block.y + block.height/2.0 + player.height/2.0 
                
          elif player.is_aabb_collision(player2):
            
              if player.x < player2.x - player2.width/2.0 and player.dx > 0:
                player.dx = 0
                player.x = player2.x - player2.width/2.0 - player.width/2.0
    
              elif player.x > player2.x + player2.width/2.0 and player.dx < 0:
                  player.dx = 0
                  player.x = player2.x + player2.width/2.0 + player.width/2.0
    
              elif player.y < player2.y:
                  player.dy = 0
                  player.y = player2.y - player2.height/2.0 - player.height/2.0 + 1
                  player.dx *= player2.friction
            
              elif player.y > player2.y:
                  player.dy = 0
                  player.y = player2.y + player2.height/2.0 + player.height/2.0 
                
          
    
          if player2.is_aabb_collision(block):
          
              if player2.x < block.x - block.width/2.0 and player2.dx > 0:
                  player2.dx = 0
                  player2.x = block.x - block.width/2.0 - player2.width/2.0
          
              elif player2.x > block.x + block.width/2.0 and player2.dx < 0:
                  player2.dx = 0
                  player2.x = block.x + block.width/2.0 + player2.width/2.0
          
              elif player2.y < block.y:
                  player2.dy = 0
                  player2.y = block.y - block.height/2.0 - player2.height/2.0 + 1
                  player2.dx *= block.friction
            
              elif player2.y > block.y:
                  player2.dy = 0
                  player2.y = block.y + block.height/2.0 + player2.height/2.0 
                
          elif player2.is_aabb_collision(player):
              
              self.state = 'end'
              
            
              if player2.x < player.x - player.width/2.0 and player2.dx > 0:
                player2.dx = 0
                player2.x = player.x - player.width/2.0 - player2.width/2.0
    
              elif player2.x > player.x + player.width/2.0 and player2.dx < 0:
                  player2.dx = 0
                  player2.x = player.x + player.width/2.0 + player2.width/2.0
    
              elif player2.y < player.y:
                  player2.dy = 0
                  player2.y = player.y - player.height/2.0 - player2.height/2.0 + 1
                  player2.dx *= player.friction
            
              elif player2.y > player.y:
                  player2.dy = 0
                  player2.y = player.y + player.height/2.0 + player2.height/2.0 
                
      # for endblock in endblocks:
      #   if player.is_aabb_collision(endblock):

      #         if player.x < endblock.x - endblock.width/2.0 and player.dx > 0:
      #             self.state = 'end'
      #             #make it go to the start screen or something
      #         elif player.x > endblock.x + endblock.width/2.0 and player.dx < 0:
      #             pygame.quit()
      #             #start screen
          
      #         elif player.y < endblock.y:
      #             pygame.quit()
      #             #start screen
            
      #         elif player.y > endblock.y:
      #             pygame.quit()

      #   if player2.is_aabb_collision(endblock):

      #         if player2.x < endblock.x - endblock.width/2.0 and player2.dx > 0:
      #             pygame.quit()
      #             #make it go to the start screen or something
      #         elif player2.x > endblock.x + endblock.width/2.0 and player2.dx < 0:
      #             pygame.quit()
      #             #start screen
          
      #         elif player2.y < endblock.y:
      #             pygame.quit()
      #             #start screen
            
      #         elif player2.y > endblock.y:
      #             pygame.quit()
          

    
    
      if player.y > 800:
          player.goto(600, 0)
          player.dx = 0
          player.dy = 0
      if player2.y > 800:
          player2.goto(600, 0)
          player2.dx = 0
          player2.dy = 0
          
    
      
      
    
      player.render()
      player2.render()
      for block in blocks:
          block.render()
      # for platfor in platform:
      #   platfor.render()
       
      # if event.key == pygame.K_k:
      #           self.state = 'end'
    
      pygame.display.flip()
    
    def state_manager(self):
      if self.state == 'intro':
        self.intro()
      if self.state == 'main_game' :
        self.main_game()


    def end(self):
        
        for event in pygame.event.get():
          if event.type == pygame.QUIT: 
              sys.exit()
          
        for block in blocks:
          blocks.pop(block)

        BackGround = Background('end.jpg', [0,0])
        screen.fill([255, 255, 255])
        screen.blit(BackGround.image, BackGround.rect)     
  
        pygame.display.flip()
        

    
    

game_state = GameState()

while True:
  mouse = pygame.mouse.get_pos() 
  
  
  game_state.state_manager()
  clock.tick(30)